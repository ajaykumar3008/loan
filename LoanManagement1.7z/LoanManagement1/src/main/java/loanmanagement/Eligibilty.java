package loanmanagement;

public class Eligibilty {

	double amountReq;
	int monthsReq;
	double annualIncome;
	double disposalIncome;
	double cibilScore;
	
	
	
	public Eligibilty() {
		
	}



	public double getAmountReq() {
		return amountReq;
	}



	public void setAmountReq(double amountReq) {
		this.amountReq = amountReq;
	}



	public int getMonthsReq() {
		return monthsReq;
	}



	public void setMonthsReq(int monthsReq) {
		this.monthsReq = monthsReq;
	}



	public double getAnnualIncome() {
		return annualIncome;
	}



	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}



	public double getDisposalIncome() {
		return disposalIncome;
	}



	public void setDisposalIncome(double disposalIncome) {
		this.disposalIncome = disposalIncome;
	}



	public double getCibilScore() {
		return cibilScore;
	}



	public void setCibilScore(double cibilScore) {
		this.cibilScore = cibilScore;
	}
	
	
	
	
}
