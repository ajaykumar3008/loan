package loanmanagement;

public class LoanManagementApp {

}
